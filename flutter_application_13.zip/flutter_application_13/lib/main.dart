import'package:flutter/material.dart';
import'package:provider/provider.dart';

void main(){
  runApp(
    ChangeNotifierProvider(
      create:(context)=>CounterProvider(),
      child:MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      home:CounterScreen(),
    );
  }
}
class CounterProvider extends ChangeNotifier{
  int _counter=0;
  int get counter=>_counter;
  void incrementCounter(){
    _counter++;
    notifyListeners();

  }
}

class CounterScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    final counterProvider =Provider.of<CounterProvider>(context);
    return Scaffold(
      appBar:AppBar(
        title:Text('Provider Example'),
      ),
      body:Center(
        child:Column(
          mainAxisAlignment:MainAxisAlignment.center,
          children:[
            Text('Counter value:${counterProvider.counter}'),
            SizedBox(height:20),
            ElevatedButton(
              onPressed:counterProvider.incrementCounter, 
            child:Text('Increment Counter'),
            ),
          ],
        ),
      ),
    );
  }
}