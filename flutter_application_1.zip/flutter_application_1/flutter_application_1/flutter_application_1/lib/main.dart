import 'dart:io';

import'package:flutter/material.dart';
void main(){
  runApp(ResponsiveAPP());
} 
class ResponsiveApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
    title:'Responsive App',
    home: ResponsiveApp(),
    ),
  }
}
class ResponsiveHomePage extends StatelessWidget{
@override
  Widget build(BuildContext context) {
  return Scaffold(
appBar: AppBar(
 title:Text('Responsive Layout'),
  
