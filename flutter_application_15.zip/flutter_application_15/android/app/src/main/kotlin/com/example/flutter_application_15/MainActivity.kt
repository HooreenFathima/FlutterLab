package com.example.flutter_application_15

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
